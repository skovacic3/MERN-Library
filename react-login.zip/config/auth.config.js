module.exports = {
    secret: "tajni-kljuc"
};