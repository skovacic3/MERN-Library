import React from 'react';

const Home = props => {
    return (
        <div>
            <p>Home Page</p>
        </div>
    );
};


export default Home;